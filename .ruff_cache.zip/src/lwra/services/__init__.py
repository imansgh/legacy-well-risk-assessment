"""Service layer: pipeline orchestration."""
